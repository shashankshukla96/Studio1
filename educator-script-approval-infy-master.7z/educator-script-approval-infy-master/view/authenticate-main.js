var user;
async function autheticate() {
    const xhr= new XMLHttpRequest();
    xhr.open('GET', 'http://localhost:3080');
    xhr.withCredentials=true;
	xhr.onload = async function () {
        userName = JSON.parse(xhr.responseText).username
        // user = userName;
        console.log("logged-in with: " + userName)
            sessionStorage.setItem('userName', userName);
    }
	xhr.send();
}

autheticate();
