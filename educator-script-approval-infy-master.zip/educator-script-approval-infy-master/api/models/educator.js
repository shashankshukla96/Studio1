const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const educatorSchema = {
    empid : {type: Number, required : true},
    name : {type : String, required : true},
    location : {type : String, required : true},
    title : {type : String, required : true},
    script : {type : String},
    // preprodstatus : {type : String, default : 'Working'},
    // prodstatus : {type : String, default : 'Working'},
    // postprodstatus : {type : String, default : 'Working'}
    status : {type: Number, default: 0},
    commments: {type: String, default: "None"}
}

module.exports = mongoose.model('Educator', educatorSchema);